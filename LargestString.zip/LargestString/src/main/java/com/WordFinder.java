package com;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;

public class WordFinder {

	public static String INVALID_INPUT = "Invalid input. Please enter valid string.";

	public static void main(String args[]) {
		if (args.length < 1) {
			System.out.println(INVALID_INPUT);
			System.exit(0);
		}

		String input = args[0];
		String[] result = longestWord(input);
		System.out.println("Length of largest string is " + result[0] + " and the string is " + result[1]);

	}

	public static String[] longestWord(String input) {
		String[] result = new String[2];
		if (StringUtils.isEmpty(input)) {
			result[0] = "-1";
			result[1] = INVALID_INPUT;
			return result;
		}

		List<String> inputList = getList(input);
		if (inputList == null || inputList.size() == 0) {
			result[0] = "-1";
			result[1] = INVALID_INPUT;
			return result;
		}

		Optional<String> maxString = inputList.stream().max(Comparator.comparingInt(String::length));
		String maxValue = maxString.get();
		result[0] = "" + maxValue.length();
		result[1] = maxValue;

		return result;
	}

	public static List<String> getList(String input) {
		return Arrays.asList(input.split(" "));
	}
}
