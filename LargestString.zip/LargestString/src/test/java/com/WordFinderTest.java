package com;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class WordFinderTest {
	WordFinder wf;

	@Before
	public void setup() {
		wf = new WordFinder();
	}

	@Test
	public void testLongestWord() {
		String input = "In the programming language of your choice";
		String[] word = wf.longestWord(input);
		assertEquals("programming", word[1]);
	}

	@Test
	public void testLongestWord_null() {
		String input = null;
		String[] word = wf.longestWord(input);
		assertEquals("Invalid input. Please enter valid string.", word[1]);
	}

	@Test
	public void testLongestWord_empty() {
		String input = "";
		String[] word = wf.longestWord(input);
		assertEquals("Invalid input. Please enter valid string.", word[1]);
	}



	@Test
	public void testLongestWord_size() {
		String input = "In the programming language of your choice";
		String[] word = wf.longestWord(input);
		assertEquals("11", word[0]);
	}

	@Test
	public void testLongestWord_null_size() {
		String input = null;
		String[] word = wf.longestWord(input);
		assertEquals("-1", word[0]);
	}

	@Test
	public void testLongestWord_empty_size() {
		String input = "";
		String[] word = wf.longestWord(input);
		assertEquals("-1", word[0]);
	}

	@Test
	public void testGetList() {
		String input = "In the programming language of your choice";
		List<String> word = wf.getList(input);
		assertEquals(7, word.size());
	}
}
