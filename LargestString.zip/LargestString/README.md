This repository has code for finding the largest word in the input sentence in String format.

The project has,
1) source files under /src/main/java
2) test files under /src/test/java

To run this tool, please follow the steps mentioned below.
you can use the following command, which takes input as command line argument.

1) Run the command
	mvn clean install package
2) jar and lib are generated in target folder.
3) Go to target folder in command prompt. i.e ${basedir}/target
4) run the command
	java -jar LargestString-1 <<INPUT>>
	e.g. :-  java -jar LargestString-1 "In the programming language of your choice"
	
Running test cases:
1) 	run the command 
	mvn surefire-report:report

2) Check the generated report at 
	${basedir}/target/site/surefire-report.html
